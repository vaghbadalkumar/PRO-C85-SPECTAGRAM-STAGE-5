export const firebaseConfig = {
    apiKey: "AIzaSyALOb9y9EGnb-6NHBKgm5tHLyzx2Xux0h4",
    authDomain: "social-media-b49aa.firebaseapp.com",
    projectId: "social-media-b49aa",
    storageBucket: "social-media-b49aa.appspot.com",
    messagingSenderId: "840110494340",
    appId: "1:840110494340:web:9cee1a25185076a091a8d1",
    measurementId: "G-67DGVLCTPQ"
};